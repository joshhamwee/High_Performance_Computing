Old Examples
===========

These examples were used in the past.
They largely aren't useful any more for modern OpenMP programming.

