HPC Course Examples
===================

This repository contains examples for the Introduction and Advanced HPC courses.
The examples range from "hello, world" to advanced topics, and include commonly used patterns and job sumission scripts.

Currently, three programming models are covered:

- [OpenACC](openacc/)
- [OpenMP](openmp/)
- [MPI](mpi/)

